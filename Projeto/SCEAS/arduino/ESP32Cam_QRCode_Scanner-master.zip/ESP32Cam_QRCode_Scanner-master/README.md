# ESP32Cam_QRCode_Scanner
ESP32Cam_QRCode_Scanner_And_show_on_3.5inch_Rpi

# Hardware
- ESP32CAM
- 3.5 inch Raspberry Pi Monitor (ILI9486)

# Software
- Arduino IDE 1.8.12
- ESP32 Board Version 1.0.1
- TFT_eSPI Library (https://github.com/Bodmer/TFT_eSPI)
- ESPino32cam Library (https://github.com/ThaiEasyElec/ESPIno32CAM)

# Circuit
- coming soon.
